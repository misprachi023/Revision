import React from 'react'

export default function Home() {
  return (
    <div>
      <h1 style={{color:"blue", fontSize:"30px", textAlign:"center"}}>Welcome to Home Page</h1>
    </div>
  )
}
